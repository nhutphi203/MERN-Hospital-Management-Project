// frontend/src/components/ChatWidget/index.ts
export { default as ChatWidget } from './ChatWidget';
export { ChatWidget as default } from './ChatWidget';
